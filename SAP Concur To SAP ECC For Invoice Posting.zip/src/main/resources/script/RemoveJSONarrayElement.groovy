import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.util.HashMap

def Message processData(Message message){
    Reader reader = message.getBody(Reader)
    def input = new JsonSlurper().parse(reader)

    input.remove("links")

    def jsonMessage = JsonOutput.toJson(input)
    message.setBody(jsonMessage)

    return message
}